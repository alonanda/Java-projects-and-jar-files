package com.employee.details;

import java.util.ArrayList;

public class CollectionClass{
	
	private  static ArrayList<Employee> myList=null;
	

	static
	{
		myList  =   new ArrayList<Employee>();
		
		Employee  e1=new Employee(101,"Suresh","ATGFH12345",33350.00);
		Employee  e2=new Employee(102,"Mahesh","POKUH28843",150200.00);
		Employee  e3=new Employee(103,"Deepak","ROPET56723",830000.00);
		Employee  e4=new Employee(104,"Pradeep","QWVGT98561",1000350.00);
		Employee  e5=new Employee(105,"Ankita","JUOLP761632",1950000.00);
		
		myList.add(e1);
		myList.add(e2);
		myList.add(e3);
		myList.add(e4);
		myList.add(e5);
	
	}
	
	public static void AddNewdetails(Employee e){
		myList.add(e);
	}
	
	public static ArrayList<Employee> getEmpList() {
		return myList;
	}
	
	public static void Display()
	{
		for(Employee ee: myList)
          System.out.println(ee.toString());		
	}
	public static void CalculateTax()
	{
		double sal=0.00d;
		double calc=0;
		System.out.println("--------------------------Payable tax------------------");
	  for(Employee err : myList)
	  {
		  System.out.println( err.toString());
		  sal =err.getSalary() ;
		  if(sal <= 250000d)
			  System.out.println("Income Tax =NIL");
		  else if(250001d < sal &&  sal<= 500000d )
		         {
			        calc= sal*0.1;
			        System.out.println("Payable Income Tax amount= "+ calc);
		         }
		  else if(500001d <  sal && sal <= 1000000d)
		    {
		        calc= sal*0.2;
		        System.out.println("Payable Income Tax amount= "+ calc);
	         }
		  else {calc = sal*0.3;
		       System.out.println("Payable Income Tax amount= "+ calc);
		  }
	  }
	  
  }
}
