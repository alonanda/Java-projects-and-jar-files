package com.employee.details;

import java.util.Scanner;

public class UI {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
	    int choice=0;
	     while(true){
	    	 
	     System.out.println("------------------------------------------------------------");
	    	System.out.println("1. Add Employee details");
	      System.out.println("2. Compute income Tax amount and display the details");
	      System.out.println("3. Exit.");
	      
	      choice=sc.nextInt();
	      
	      switch(choice)
	      {
	      case 1:  addEmpDetails();
	                  break;
	                  
	      case 2:   ComputeAndDisplay();
	                    break;
	         
	      case 3: System.out.println("-----Exited------");
	    	          System.exit(1);;
	                    
	      default: System.out.println("--please choose from above choices--");
	      }
	}
}
	
	
	  public static void addEmpDetails()
      {
    	  Scanner sc= new Scanner(System.in);
    	  
    	do{
    		System.out.println("---------------INPUT_DETAILS---------------------------------------------");
    		System.out.println("----------(press 5 to exit anytime in between input process)-------------");
    		System.out.print("enter empId = ");
    		String id=sc.nextLine();
    		Eql(id);
    	    if(Validator.ValidId(id)){
    		      System.out.print("Enter empName = ");
    		       String name =sc.nextLine();
    		         Eql(name);
    		             if(Validator.ValidEname(name)){
    		                  System.out.print("Enter EPAN:- ");
    		                  String epan=sc.nextLine();
    		                    Eql(epan);
    		                         if(Validator.ValidEpan(epan)){
    		                        	System.out.print("Enter Salary:- ");
    		                             String esal=sc.nextLine();
    		                             Eql(esal);
    		                if(Validator.ValidSalary(esal)){
    		                	 Employee emp1=new Employee(Integer.parseInt(id), name, epan,Double.parseDouble(esal));
    		                	 CollectionClass.AddNewdetails(emp1);
    		            	       break;
    		            	}else System.out.println("------please enter valid employee salary must contain 2 decimal places (ex:-100000351.00)--------"+"\n");
    		            	}else System.out.println("(-----please enter valid employee pan no 10digits long (ex:-ABCDE12345)-----)"+"\n");
    		        } else System.out.println("(-----please enter valid employee name with first letter capital and max 10 characters with no space (ex:-Naman)-----)"+"\n");
            } else System.out.println("(-------please enter valid 3 digit employe id staring with 1 (ex:- 101)------)"+"\n");
    	}while(true);
    	
    	System.out.println("-------------------------------------------");
    	System.out.println("Employee details are Added Sucessfully..!!!");
    	System.out.println("-------------------------------------------");
    }
	  
	  public static void  Eql(String s)
	  {
		  if(s.equals("5")){
			  System.out.println("-----Exited------");
			  System.exit(0);
		  }  
	  }
	  
	  public static void ComputeAndDisplay()
	  {
		  System.out.println("|  --Income range--      |         |--Income Tax Rate--|");
		  System.out.println("| upto rs 2,50,000        |         |                 Nil           |");
		  System.out.println("| 2,50,001 to 5,00,000  |         |                 10%         |");
		  System.out.println("| 5,00,001 to 10,00,000|         |                 20%         |");
		  System.out.println("|   above 10,00,000       |         |                 30%         |");
          /*function to calculate payable income tax in collection class*/
		  CollectionClass.CalculateTax();
	  }
}