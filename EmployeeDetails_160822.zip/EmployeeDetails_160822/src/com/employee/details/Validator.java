package com.employee.details;

import java.util.regex.Pattern;

public class Validator {
	
	public static boolean ValidId(String empId)
	{
		String reg = "^[1][0-9]{2}$";
		return(Pattern.matches(reg, empId));
	}
	
	public static boolean ValidEname(String empName)
	{
		String reg = "^[A-Z][a-z]{1,10}$";
		return(Pattern.matches(reg, empName));
	}
	
	public static boolean ValidEpan(String empPAN)
	{
		String reg = "^[A-Z]{5}[0-9]{5}$";
		return(Pattern.matches(reg, empPAN));
	}
	
	public static boolean ValidSalary(String empSalary)
	{
		String reg = "^\\d+\\.\\d{1,2}$";
		return(Pattern.matches(reg, empSalary));
	}

}
