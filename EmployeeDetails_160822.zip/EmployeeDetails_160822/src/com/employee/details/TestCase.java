package com.employee.details;

import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.Test;

public class TestCase {

	static CollectionClass v;
	static Employee e=null;
	
	@BeforeClass
	public   static  void beforeClass()
	{
		v=new CollectionClass();
		e =new Employee(111,"Namanawasthi","ADCSS12345",123.00);		
	}
	@AfterClass
	public static  void afterClass()
	{		
		v=null;
		e=null;
	}	
	
	
	@Test 
	public void testAddEmpDetails() 
	{
		CollectionClass.AddNewdetails(e);
		//Assert.assertEquals(4, collectionHelper.getCustList().size());
		Assert.assertNotNull(e.toString());
		
	}
	
	@Test 
	public void display()
	{
		CollectionClass.Display();
	}
}
