import java.util.regex.Pattern;

public class EmpValidation {
	public boolean EId(int i) {
		String pattern = "\\d{3}";
		String Strnum = String.valueOf(i);
		return Pattern.matches(pattern, Strnum);

	}

	public boolean Ename(String s) {
		String pattern = "^[a-zA-Z\\s]+";
		return Pattern.matches(pattern, s);

	}

	public boolean AnnualSal(double d) {
		String pattern = "[0-9]+([,.][0-9]{1,2})?";
		String Strnum = String.valueOf(d);
		return Pattern.matches(pattern, Strnum);

	}

	public boolean EPan(String d) {
		String pattern = "[A-Z]{5}[0-9]{5}";
		String Strnum = String.valueOf(d);
		return Pattern.matches(pattern, Strnum);

	}

}
