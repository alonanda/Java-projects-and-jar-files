import java.util.ArrayList;
import java.util.Scanner;

public class EmpMain {
	static EmpCollection collectionhelper = null;

	public static void main(String[] args) {
		boolean i = true;
		collectionhelper = new EmpCollection();
		int opt = 0;
		EmpService s = new EmpService();
		Scanner sc = new Scanner(System.in);
		EmpMain ui = new EmpMain();
		while (i) {
			System.out.println("---------------------------------");
			System.out.println("1.Enter Employee details");
			System.out.println("2.Display details");
			System.out.println("3.Check Income Tax");
			System.out.println("4.Exit System");
			System.out.println("---------------------------------");
			int opt1 = sc.nextInt();
			switch (opt1) {
			case 1: {
				EmpService es = new EmpService();
				es.getEmployeeDetails();

				break;
			}
			case 2: {
				EmpService es = new EmpService();
				collectionhelper.displayEmployeeCount();
				break;
			}
			case 3: {
				EmpService es = new EmpService();
				es.getSalary();
				break;
			}
			case 4: {
				System.exit(0);
				break;
			}
			default: {
				System.out.println("Please Enter Only Given Input\n");
				System.exit(0);

			}
			}
		}

	}

}
