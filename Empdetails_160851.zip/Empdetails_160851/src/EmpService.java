import java.util.*;

public class EmpService {
	static EmpCollection collectionhelper = null;

	public void getEmployeeDetails() {
		EmpCollection ec = new EmpCollection();
		collectionhelper = new EmpCollection();
		EmpValidation val = new EmpValidation();
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter EmpId: ");
		int Id = scr.nextInt();
		if (val.EId(Id)) {
			System.out.println("Enter Employee Name: ");
			String name = scr.next();
			if (val.Ename(name)) {
				System.out.println("Enter Pan Card Number: ");
				String Pan = scr.next();
				if (val.EPan(Pan)) {
					System.out.println("Enter Annual Salary: ");
					double Sal = scr.nextDouble();
					if (val.AnnualSal(Sal)) {
						EmpSchema sch = new EmpSchema(Id, name, Pan, Sal);
						System.out.println(sch);
						collectionhelper.addNewEmployeeDetails(sch);
					}

					else {
						System.out.println("Please Enter  A PROPER SALARY");
					}
				} else {
					System.out.println("INCORRECT PAN NUMBER");

				}
			} else {
				System.out.println("NAME SHOULD CONTAIN ONLY ALPHABETS");

			}
		}

		else {
			System.out.println("Please Enter 3 DIGIT ID ONLY");
		}

	}

	public void getSalary() {
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter Salary: ");
		long salary1 = scr.nextInt();
		
		if ((salary1 < 250000)) {
			System.out.println("Nil Income Tax");
		}  else if ((salary1 >= 250000 && salary1 < 500000)) {
			System.out.println("10%");
		}  else if ((salary1 >= 500000 && salary1 <= 1000000)) {
			System.out.println("20%");
		}  else if ((salary1 < 1000000)) {
			System.out.println("30%");
		} else {
			System.out.println("Wrong Input!!!");
		}

	}

}
