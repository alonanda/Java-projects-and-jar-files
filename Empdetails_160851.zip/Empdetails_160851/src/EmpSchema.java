public class EmpSchema {
	int EId;
	String Ename;
	String EPan;
	Double AnnualSal;

	public int getEId() {
		return EId;
	}

	public void setEId(int eId) {
		EId = eId;
	}

	public String getEname() {
		return Ename;
	}

	@Override
	public String toString() {
		return "EId=" + EId + "\nEname=" + Ename + "\nEPan=" + EPan
				+ "\nAnnualSal=" + AnnualSal + "\n------------------";
	}

	public EmpSchema(String Name) {
		super();
		this.EId = 001;
		this.Ename = Name;
		this.EPan = "";
		this.AnnualSal = 12343.00;
	}

	public EmpSchema(int eId, String ename, String ePan, Double annualSal) {
		super();
		EId = eId;
		Ename = ename;
		EPan = ePan;
		AnnualSal = annualSal;
	}

	public void setEname(String ename) {
		Ename = ename;
	}

	public String getEPan() {
		return EPan;
	}

	public void setEPan(String ePan) {
		EPan = ePan;
	}

	public Double getAnnualSal() {
		return AnnualSal;
	}

	public void setAnnualSal(Double annualSal) {
		AnnualSal = annualSal;
	}
}
