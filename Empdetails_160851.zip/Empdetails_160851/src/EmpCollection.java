import java.util.ArrayList;
import java.util.Iterator;

public class EmpCollection {

	private static ArrayList<EmpSchema> EmployeeList = null;
	static {
		EmployeeList = new ArrayList<EmpSchema>();
		EmpSchema b1 = new EmpSchema(101, "Suresh", "ATGFH12345", 33350.00);
		EmpSchema b2 = new EmpSchema(102, "Mahesh", "POKUH28843", 150200.00);
		EmpSchema b3 = new EmpSchema(103, "Deepak", "ROPET56723", 830000.00);
		EmpSchema b4 = new EmpSchema(104, "Pradeep", "QWVGT98561", 1000350.00);
		EmpSchema b5 = new EmpSchema(105, "Ankita", "JUOLP76163", 1950000.00);
		EmployeeList.add(b1);
		EmployeeList.add(b2);
		EmployeeList.add(b3);
		EmployeeList.add(b4);
		EmployeeList.add(b5);

	}

	/************* Add New Employee in ArrayList ************/
	public void addNewEmployeeDetails(EmpSchema es) {
		EmployeeList.add(es);
	}

	public static ArrayList<EmpSchema> getEmployeeList() {
		return EmployeeList;
	}

	public static void setEmployeeList(ArrayList<EmpSchema> EmployeeList) {
		EmpCollection.EmployeeList = EmployeeList;
	}

	/************* Fetch All Book Details ***********/

	public void displayEmployeeCount() {
		Iterator<EmpSchema> employee = EmployeeList.iterator();
		EmpSchema tempemployee = null;

		int totalCount = 0;
		while (employee.hasNext()) {
			totalCount++;
			tempemployee = employee.next();
			System.out.println(tempemployee);
		}
		System.out.println("Total Count " + totalCount);

	}
}